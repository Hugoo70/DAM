package Pr3;

import com.google.gson.Gson;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {

	public static void main(String[] args) {
		Gson gson = new Gson();
		/**
		 *  Creamos un HashMap en vez de ArrayList que busca el id cliente por cliente.
		 *  Con HashMap busca el id del tiron ya que declaramos la clave con el id de los Clientes.
		 */
		HashMap<String, Cliente> clientesMap = new HashMap<>();

		// Bucle para sacar todos los clientes del Json y meterlos en el HashMap para
		// poder operar con ellos.
		for (int i = 1; i <= 6; i++) {
			String fileC = "data//Cliente" + i + ".json";
			try (FileReader reader = new FileReader(fileC)) {
				Cliente cliente = gson.fromJson(reader, Cliente.class);
				// Declaramos el HashMap con la clave como id y el cliente.
				clientesMap.put(cliente.getId(), cliente);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		// Mostrar clientes para comprobar que se añadieron correctamente
		// Con el HashMap el forEach es igual que un ArrayList solo que al nombre del HashMap se le añade un .values() para mostrar los datos
		System.out.println("Clientes iniciales:");
		for (Cliente cliente : clientesMap.values()) {
			System.out.println(cliente);
		}

		// Crear un pool con un hilo por cada transferencia (10)
		ExecutorService executorService = Executors.newFixedThreadPool(10);

		// Bucle para sacar todas las transferencias llamando a la funcion
		// procesarTransferencia donde lanzaremos todos los hilos.
		for (int i = 1; i <= 10; i++) {
			String fileT = "data//transferencias" + i + ".json";
			executorService.submit(() -> procesarTransferencias(fileT, gson, clientesMap));
		}

		// Cerrar el pool de hilos cuando acaben todos
		while (!executorService.isTerminated()) {
			executorService.shutdown();

		}

		/**
		 *  Bucle para mostrar de nuevo a los clientes después de las transferencias y
		 *  ver cómo ha quedado su saldo.
		 */
		
		System.out.println("\nSaldos finales:");
		for (Cliente cliente : clientesMap.values()) {
			System.out.println(cliente.getNombre() + " tiene ahora un saldo de " + cliente.getSaldo());

		}
	}

	/**
	 * Sacar las transferencias de los Json. Calcular las transferencias y
	 * establecer el saldo tras los movimientos.
	 * 
	 * @param file          Nombre del archivo donde estan las transferencias.
	 * @param gson          Objeto del Gson.
	 * @param clientesMap	HashMap donde se guardan todos los clientes sacados del JSON de clientes.
	 */
	
	private static void procesarTransferencias(String file, Gson gson, HashMap<String, Cliente> clientesMap) {
		try (FileReader reader = new FileReader(file)) {
			Transferencia[] transferencias = gson.fromJson(reader, Transferencia[].class);

			// Bucle para operar con cada transferencia
			for (Transferencia t : transferencias) {

				// Operamos con el cliente origen usando la función para encontrarlo, buscando
				// en el array el id y sacando el nombre del Origen.
				Cliente clienteOrigen = encontrarCliente(clientesMap, t.getOrigen());
				/*
				 * Comprobamos por si acaso que no sea null. - Si lo es decimos que cliente no
				 * encontrado. - Si lo encuentra restamos su saldo con el monto.
				 */
				Cliente clienteDestino = encontrarCliente(clientesMap, t.getDestino());

				if (clienteOrigen != null && clienteDestino != null) {
					synchronized (clienteOrigen) {
						synchronized (clienteDestino) {
							clienteOrigen.setSaldo(clienteOrigen.getSaldo() - t.getMonto());
							clienteDestino.setSaldo(clienteDestino.getSaldo() + t.getMonto());

						}
					}
				} else if (clienteOrigen == null) {
					System.err.println("Cliente origen no encontrado: ID " + t.getOrigen());

				} else {
					System.err.println("Cliente destino no encontrado: ID " + t.getDestino());
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Función para recorrer los clientes. Si el ID del cliente es igual al del
	 * Origen/Destinatario, devuelve el cliente. Si no, devuelve null.
	 * 
	 * @param clientesMap HashMap de los clientes de los JSON
	 * @param id          Id del Origen o Destino para comparar.
	 * @return cliente Cliente con el mismo id
	 */
	private static Cliente encontrarCliente(HashMap<String, Cliente> clientesMap, String id) {
		return clientesMap.get(id);
	}
}
